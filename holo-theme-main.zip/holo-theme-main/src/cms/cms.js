
import CMS from 'decap-cms-app'
CMS.init()
// CMS.registerPreviewTemplate('my-template', MyTemplate)